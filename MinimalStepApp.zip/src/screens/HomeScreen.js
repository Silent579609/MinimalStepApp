import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ProgressBar } from 'react-native-paper';

const initialTasks = [
  'Заправь кровать',
  'Выпей стакан воды',
  'Сделай 5 отжиманий',
  'Пойди на прогулку',
  'Прочитай 10 минут',
];

const quotes = [
  'Маленькие шаги ведут к большим успехам!',
  'Верь в себя — ты способен на большее!',
  'Каждая задача — это шаг к лучшей версии себя.',
  'Действие — это ключ к успеху!',
  'У тебя всё получится!',
];

export default function HomeScreen() {
  const [points, setPoints] = useState(0);
  const [dailyTasks, setDailyTasks] = useState(0);
  const [tasksList, setTasksList] = useState(initialTasks.map(task => ({ title: task, completed: false })));
  const [quote, setQuote] = useState('');
  const dailyGoal = 5;

  const loadInitialData = async () => {
    const storedDailyTasks = await AsyncStorage.getItem('dailyTasks');
    const storedPoints = await AsyncStorage.getItem('points');
    if (storedDailyTasks) setDailyTasks(parseInt(storedDailyTasks, 10));
    if (storedPoints) setPoints(parseInt(storedPoints, 10));
    setQuote(quotes[Math.floor(Math.random() * quotes.length)]);
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  const updateProgress = async () => {
    if (dailyTasks < dailyGoal) {
      const newDailyTasks = dailyTasks + 1;
      setDailyTasks(newDailyTasks);
      await AsyncStorage.setItem('dailyTasks', newDailyTasks.toString());

      const newPoints = points + 10;
      setPoints(newPoints);
      await AsyncStorage.setItem('points', newPoints.toString());
    }
  };

  const handleTaskCompletion = async (index) => {
    if (tasksList[index].completed) {
      Alert.alert('Задача уже выполнена', 'Вы не можете выполнить одну задачу дважды.');
      return;
    }

    const updatedTasks = [...tasksList];
    updatedTasks[index].completed = true;
    setTasksList(updatedTasks);

    updateProgress();
    setQuote(quotes[Math.floor(Math.random() * quotes.length)]);
  };

  const undoTask = async (index) => {
    if (!tasksList[index].completed) {
      Alert.alert('Отмена невозможна', 'Эта задача ещё не была выполнена.');
      return;
    }

    const updatedTasks = [...tasksList];
    updatedTasks[index].completed = false;
    setTasksList(updatedTasks);

    if (dailyTasks > 0) {
      const newDailyTasks = dailyTasks - 1;
      setDailyTasks(newDailyTasks);
      await AsyncStorage.setItem('dailyTasks', newDailyTasks.toString());

      const newPoints = points > 0 ? points - 10 : 0;
      setPoints(newPoints);
      await AsyncStorage.setItem('points', newPoints.toString());
    }
  };

  const progress = Math.min(dailyTasks / dailyGoal, 1);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Список задач:</Text>
      <Text style={styles.points}>Очки: {points}</Text>

      <ScrollView style={styles.taskList}>
        {tasksList.map((task, index) => (
          <View key={index} style={styles.taskItem}>
            <Text style={[styles.taskText, task.completed && styles.completed]}>
              {task.title}
            </Text>
            <View style={styles.taskButtons}>
              {!task.completed && (
                <TouchableOpacity
                  style={styles.completeButton}
                  onPress={() => handleTaskCompletion(index)}
                >
                  <Text style={styles.buttonText}>Выполнить</Text>
                </TouchableOpacity>
              )}
              {task.completed && (
                <TouchableOpacity
                  style={styles.undoButton}
                  onPress={() => undoTask(index)}
                >
                  <Text style={styles.buttonText}>Отменить</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        ))}
      </ScrollView>

      <Text style={styles.quote}>{quote}</Text>

      <Text style={styles.dailyProgress}>
        Выполнено задач: {dailyTasks} / {dailyGoal}
      </Text>

      <ProgressBar
        progress={progress}
        style={styles.progressBar}
        color={progress < 1 ? '#FFD700' : '#4CAF50'}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#121212',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  points: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4CAF50',
    position: 'absolute',
    top: 20,
    right: 20,
  },
  taskList: {
    flex: 1,
    marginTop: 10,
  },
  taskItem: {
    backgroundColor: '#1E1E1E',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  taskText: {
    fontSize: 16,
    color: '#ddd',
    flex: 1,
  },
  completed: {
    textDecorationLine: 'line-through',
    color: '#888',
  },
  taskButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  completeButton: {
    backgroundColor: '#4CAF50',
    padding: 8,
    borderRadius: 5,
    marginLeft: 5,
  },
  undoButton: {
    backgroundColor: '#FF6347',
    padding: 8,
    borderRadius: 5,
    marginLeft: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  quote: {
    fontSize: 16,
    fontStyle: 'italic',
    color: '#ddd',
    marginVertical: 10,
    textAlign: 'center',
  },
  dailyProgress: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginVertical: 10,
    textAlign: 'center',
  },
  progressBar: {
    height: 8,
    borderRadius: 4,
    marginTop: 10,
  },
});
